def q():
    print('qq')